# canvas basic - firework - happy new year!

A Pen created on CodePen.io. Original URL: [https://codepen.io/haidang/pen/eBoqyw](https://codepen.io/haidang/pen/eBoqyw).

an example for canvas basic drawing  - firework! Here is my better version for firework: http://codepen.io/haidang/full/WRGXJv/